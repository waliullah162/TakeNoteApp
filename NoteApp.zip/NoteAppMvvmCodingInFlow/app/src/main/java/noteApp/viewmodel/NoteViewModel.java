package noteApp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import java.util.List;

import noteApp.model.Note;
import noteApp.repository.NoteRepository;

public class NoteViewModel extends AndroidViewModel {
    private NoteRepository repository;
    LiveData<List<Note>>allNotes;



    public NoteViewModel(@NonNull Application application) {
        super(application);


        repository=new NoteRepository(application);
        allNotes=repository.getAllNotes();
        //when assigning the notes we have to cut the param

    }

    public void insertNote(Note note){
        repository.insertNote(note);
    }

    public void updateNote(Note note){
        repository.updateNote(note);
    }

    public void deleteNote(Note note){
        repository.deleteNote(note);
    }
//will it take parameter?

    public void deleteAllNotes(){
        repository.deleteAllNotes();
    }


    public LiveData<List<Note>>getAllNotes(){
        return allNotes;

    }


}

