package noteApp.constants;

public class Constants {
}
