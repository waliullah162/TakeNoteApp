package noteApp.view;
import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import noteApp.viewmodel.NoteViewModel;
class MyViewModelFactory implements ViewModelProvider.Factory {
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return null;
    }
//    private Application mApplication;
//
//
//
//    public MyViewModelFactory(Application application) {
//        mApplication = application;
//    }
//
//
//    @Override
//    public <T extends ViewModel> T create(Class<T> modelClass) {
//        return (T) new NoteViewModel(mApplication);
//    }
}