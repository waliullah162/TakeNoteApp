package noteApp.database;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import noteApp.model.Note;

@Database(entities = {Note.class}, exportSchema = false, version = 1)
public abstract class NoteDatabase extends RoomDatabase{

    private static final String LOG_TAG=NoteDatabase.class.getSimpleName();
    private static final Object LOCK=new Object();
    private static final String DATABASE_NAME="note_list";
    private static NoteDatabase sInstance;


    public static NoteDatabase getInstance(Context context){
        if(sInstance==null){
            synchronized (LOCK){
                Log.d(LOG_TAG, "Creating new database instance");
                sInstance= Room.databaseBuilder(context.getApplicationContext(),NoteDatabase.class,NoteDatabase.DATABASE_NAME).build();

            }
        }
        Log.d(LOG_TAG,"Getting the database instance");

        return sInstance;

    }

   public abstract NoteDao noteDao();

    private static RoomDatabase.Callback roomCallback=new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            //populate our database
            new PopulateDbAsyncTask(sInstance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void,Void,Void>{
        private NoteDao noteDao;

        private PopulateDbAsyncTask(NoteDatabase db){
            noteDao=db.noteDao();
        }


        @Override
        protected Void doInBackground(Void... voids) {
            noteDao.insertNote(new Note("Title 1","Description 1",1));
            noteDao.insertNote(new Note("Title 2","Description 2",2));
            noteDao.insertNote(new Note("Title 3","Description 3",3));
            return null;
        }
    }


}
