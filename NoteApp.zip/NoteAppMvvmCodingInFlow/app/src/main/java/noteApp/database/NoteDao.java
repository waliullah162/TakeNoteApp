package noteApp.database;

import androidx.annotation.RequiresPermission;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import noteApp.model.Note;

@Dao
public interface NoteDao {

    @Insert
    void insertNote(Note note);

    @Update
    void updateNote(Note note);

    @Delete
    void deleteNote(Note note);


    @Query("DELETE FROM note_table")
    void deleteAllNotes();

    @Query("SELECT * FROM  note_table  ORDER BY priority")
    LiveData<List<Note>> getAllNotes();
//we have to return with live data because we return from same as repository constructor



}
