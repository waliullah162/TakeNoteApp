package noteApp.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import javax.xml.transform.Result;

import noteApp.database.NoteDao;
import noteApp.database.NoteDatabase;
import noteApp.model.Note;

public class NoteRepository {

    private NoteDao noteDao;
    private LiveData<List<Note>>allNotes;

    //we need to create a constructor and we have to pass an Application instance as a context

    //If we want to pass data to Database class, we have to create a Constructor and
    // through this constructor we can pass the data to the database



    public NoteRepository(Application application){

        //we can use it as a context to create database instance
        NoteDatabase database=NoteDatabase.getInstance(application);
        noteDao=database.noteDao();
        allNotes= (LiveData<List<Note>>) noteDao.getAllNotes();


    }


    public void insertNote(Note note){

        new InsertNoteAsyncTask(noteDao).execute(note);

    }

    public void updateNote(Note note){
        new UpdateNoteAsyncTask(noteDao).execute(note);

    }


    public void deleteNote(Note note){

        new DeleteNoteAsyncTask(noteDao).execute(note);

    }

    //will it take parameter ???

    public void deleteAllNotes(){
        new DeleteAllNotesAsyncTask(noteDao).execute();

    }

    public  LiveData<List<Note>>getAllNotes(){
        return allNotes;
    }

    //Room doesn't support to do something in main thread
    //Insert AsyncTask
    public static class InsertNoteAsyncTask extends AsyncTask<Note,Void,Void>{
        private NoteDao noteDao;

        private InsertNoteAsyncTask(NoteDao noteDao){
            this.noteDao=noteDao;
        }


        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.insertNote(notes[0]);
            return null;
        }
    }

    //update AsyncTask
    public static class UpdateNoteAsyncTask extends AsyncTask<Note,Void,Void>{
        private NoteDao noteDao;

        private UpdateNoteAsyncTask(NoteDao noteDao){
            this.noteDao=noteDao;
        }


        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.updateNote(notes[0]);
            return null;
        }
    }

    //Delete AsyncTask
    public static class DeleteNoteAsyncTask extends AsyncTask<Note,Void,Void>{
        private NoteDao noteDao;

        private DeleteNoteAsyncTask(NoteDao noteDao){
            this.noteDao=noteDao;
        }


        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.deleteNote(notes[0]);
            return null;
        }
    }

    //deleteAll AsyncTask
    public static class DeleteAllNotesAsyncTask extends AsyncTask<Void,Void,Void>{
        private NoteDao noteDao;

        private DeleteAllNotesAsyncTask(NoteDao noteDao){
            this.noteDao=noteDao;
        }


        @Override
        protected Void doInBackground(Void... Voids) {
            noteDao.deleteAllNotes( );
            return null;
        }
    }



    }


